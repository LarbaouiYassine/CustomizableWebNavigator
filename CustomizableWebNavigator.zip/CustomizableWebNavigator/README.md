

--------------STEPS OF USE---------------------

1. Add the JitPack repository to your build file in xml

<repositories>
	<repository>
		  <id>jitpack.io</id>
		  <url>https://jitpack.io</url>
	</repository>
</repositories>

2. Add the dependency in xml
 <dependency>
	   <groupId>com.github.LarbaouiYassine</groupId>
	   <artifactId>Customizable-Web-Navigator</artifactId>
	   <version>Tag</version>
  </dependency>


3. 

Create one intance or multiple instances of Browser as follow:

    JAVA
public WebBrowserController webBrowser = new WebBrowserController();
-------------------

and add it for example inside a BorderPane :

    JAVA
BorderPane borderPane = new BorderPane( webBrowser );
--------------------



