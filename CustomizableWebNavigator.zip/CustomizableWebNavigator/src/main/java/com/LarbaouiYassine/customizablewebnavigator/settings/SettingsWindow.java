package main.java.com.LarbaouiYassine.customizablewebnavigator.settings;

public class SettingsWindow {
	
}
